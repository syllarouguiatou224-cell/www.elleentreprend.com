# 🚀 Elle Entreprend - UJNK 2026 | Site d'Inscription

Site complet d'inscription en ligne pour le projet **Elle Entreprend - UJNK 2026**.

## 📋 Caractéristiques

✅ **Site d'inscription responsive** - Formulaire professionnel et attrayant  
✅ **Panneau d'administration** - Visualiser et gérer les inscriptions  
✅ **Backend Node.js/Express** - API REST complète  
✅ **Stockage JSON** - Pas de base de données externe requise  
✅ **Export CSV** - Télécharger les inscriptions en CSV  
✅ **Recherche en temps réel** - Filtrer les inscriptions  

---

## 🛠️ Installation Locale

### Prérequis
- Node.js v14+ 
- npm

### Étapes

1. **Cloner ou télécharger le projet**
```bash
cd elle_entreprend_site
```

2. **Installer les dépendances**
```bash
npm install
```

3. **Démarrer le serveur**
```bash
npm start
```

4. **Accéder aux sites**
- 🌐 Site d'inscription: http://localhost:3000
- 📊 Panneau admin: http://localhost:3000/admin

---

## 🌍 Hébergement en Ligne

### Option 1: Heroku (Gratuit)

1. **Créer un compte Heroku** (heroku.com)

2. **Installer Heroku CLI**
```bash
# macOS
brew tap heroku/brew && brew install heroku

# Windows
# Télécharger depuis heroku.com/download

# Linux
curl https://cli-assets.heroku.com/install-ubuntu.sh | sh
```

3. **Se connecter à Heroku**
```bash
heroku login
```

4. **Créer une app Heroku**
```bash
heroku create elle-entreprend-ujnk-2026
```

5. **Déployer le code**
```bash
git push heroku main
# ou si vous n'avez pas Git:
heroku create
git init
git add .
git commit -m "Initial commit"
git push heroku master
```

6. **Ouvrir le site**
```bash
heroku open
```

### Option 2: Render (Gratuit)

1. **Créer un compte Render** (render.com)

2. **Créer un nouveau Web Service**
   - Connecter le repo GitHub
   - Sélectionner "Node"
   - Entrer `npm start` comme commande de démarrage

3. **Déployer automatiquement**

### Option 3: Railway (Gratuit avec crédit)

1. **Créer un compte Railway** (railway.app)

2. **Connecter le repo GitHub**

3. **Railway détectera automatiquement Node.js**

---

## 📁 Structure du Projet

```
elle_entreprend_site/
├── server.js              # Serveur Node.js/Express
├── package.json          # Dépendances
├── public/
│   ├── index.html        # Site d'inscription
│   └── admin.html        # Panneau d'administration
├── data/
│   └── inscriptions.json  # Stockage des données
└── README.md
```

---

## 🔌 API Endpoints

### POST /api/inscriptions
Soumettre une nouvelle inscription

**Paramètres:**
```json
{
  "nom": "Diallo",
  "prenom": "Aminata",
  "email": "oussama@example.com",
  "telephone": "620770934",
  "universite": "UJNK",
  "categorie": "etudiante",
  "domaine": "numerique",
  "projet": "Application mobile...",
  "interessements": ["leadership", "business", "pitch"]
}
```

### GET /api/inscriptions
Récupérer toutes les inscriptions (admin)

### GET /api/statistiques
Récupérer les statistiques

### DELETE /api/inscriptions/:id
Supprimer une inscription

---

## 📧 Configuration Email

Pour envoyer des emails de confirmation automatiques, modifier `server.js`:

```javascript
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'votre_email@gmail.com',
    pass: 'votre_mot_de_passe'
  }
});

// Dans la route POST /api/inscriptions, ajouter:
await transporter.sendMail({
  from: 'noreply@elleentreprend.com',
  to: email,
  subject: 'Inscription confirmée - Elle Entreprend UJNK 2026',
  html: `<h2>Bienvenue ${prenom}!</h2>...`
});
```

---

## 🔒 Sécurité

**À faire en production:**
- ✅ Ajouter validation côté serveur
- ✅ Utiliser HTTPS
- ✅ Ajouter rate limiting
- ✅ Protéger le panneau admin avec authentification
- ✅ Valider les emails (vérifier que l'email est valide)
- ✅ Utiliser une vraie base de données (MongoDB, PostgreSQL)

**Modification du server.js pour protéger l'admin:**

```javascript
const basicAuth = require('express-basic-auth');

app.use('/api/inscriptions', basicAuth({
  users: { 'admin': 'motdepasse123' },
  challenge: true
}));
```

---

## 📊 Utilisation du Panneau Admin

1. Accéder à `http://localhost:3000/admin`
2. Voir le nombre total d'inscriptions
3. Voir le breakdown par catégorie
4. Rechercher une inscription
5. Exporter les données en CSV
6. Supprimer une inscription si nécessaire

---

## 💬 Contacts & Support

**Email:** foturemindinstitute@gmail.com  
**Téléphone:** +224 620 770 934  

---

## 📝 License

MIT License - Libre d'utilisation

---

## 🎉 Prêt à accueillir vos participantes!

Le site est maintenant prêt pour recevoir des inscriptions en ligne. Partagez le lien avec vos participantes potentielles.

**URL d'inscription:** `https://votre-domaine.com`  
**URL Admin:** `https://votre-domaine.com/admin`

Bonne chance pour l'événement Elle Entreprend - UJNK 2026! 🚀
