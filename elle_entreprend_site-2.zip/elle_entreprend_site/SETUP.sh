#!/bin/bash

echo "🚀 Elle Entreprend - UJNK 2026 | Script de Déploiement"
echo "========================================================="
echo ""

# Vérifier Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js n'est pas installé"
    echo "Télécharger depuis: https://nodejs.org"
    exit 1
fi

echo "✅ Node.js trouvé: $(node -v)"
echo ""

# Installer les dépendances
echo "📦 Installation des dépendances..."
npm install

echo ""
echo "✅ Installation terminée!"
echo ""

# Informations pour démarrage
echo "🎯 Pour démarrer le serveur, exécuter:"
echo "   npm start"
echo ""
echo "📍 URLs d'accès:"
echo "   - Site d'inscription: http://localhost:3000"
echo "   - Panneau admin: http://localhost:3000/admin"
echo ""
echo "🌍 Pour héberger en ligne:"
echo "   1. Heroku: https://heroku.com"
echo "   2. Render: https://render.com"
echo "   3. Railway: https://railway.app"
echo "   4. Vercel + serverless"
echo ""
echo "📧 Contacts:"
echo "   Email: foturemindinstitute@gmail.com"
echo "   Tel: +224 620 770 934"
echo ""
