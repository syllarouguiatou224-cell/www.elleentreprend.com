// ===== SERVER.JS - Backend Node.js/Express =====
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Fichier de stockage des inscriptions
const DATA_FILE = path.join(__dirname, 'data', 'inscriptions.json');

// Créer le dossier data s'il n'existe pas
if (!fs.existsSync(path.join(__dirname, 'data'))) {
    fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}

// Initialiser le fichier data
if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({
        inscriptions: [],
        statistiques: {
            total: 0,
            parCategorie: {
                etudiante: 0,
                diplom: 0,
                porteuseProjet: 0
            }
        }
    }, null, 2));
}

// Fonction pour lire les inscriptions
function getLesInscriptions() {
    try {
        const data = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        return { inscriptions: [], statistiques: { total: 0, parCategorie: { etudiante: 0, diplom: 0, porteuseProjet: 0 } } };
    }
}

// Fonction pour sauvegarder les inscriptions
function saveInscriptions(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// ===== ROUTES API =====

// POST: Soumettre une inscription
app.post('/api/inscriptions', (req, res) => {
    const {
        nom,
        prenom,
        email,
        telephone,
        universite,
        categorie,
        domaine,
        projet,
        interessements
    } = req.body;

    // Validation basique
    if (!nom || !prenom || !email || !telephone || !categorie) {
        return res.status(400).json({ success: false, message: 'Tous les champs requis doivent être remplis' });
    }

    // Créer une nouvelle inscription
    const nouvelleInscription = {
        id: Date.now(),
        nom,
        prenom,
        email,
        telephone,
        universite,
        categorie,
        domaine,
        projet,
        interessements,
        dateInscription: new Date().toISOString()
    };

    // Lire les données existantes
    const data = getLesInscriptions();

    // Vérifier si l'email existe déjà
    const emailExiste = data.inscriptions.some(insc => insc.email === email);
    if (emailExiste) {
        return res.status(400).json({ success: false, message: 'Cet email est déjà inscrit' });
    }

    // Ajouter la nouvelle inscription
    data.inscriptions.push(nouvelleInscription);
    data.statistiques.total = data.inscriptions.length;
    data.statistiques.parCategorie[categorie] = (data.statistiques.parCategorie[categorie] || 0) + 1;

    // Sauvegarder
    saveInscriptions(data);

    // Envoyer un email (simulé - en production utiliser nodemailer)
    console.log(`✅ Nouvelle inscription: ${prenom} ${nom} (${email})`);

    res.status(201).json({
        success: true,
        message: 'Inscription confirmée! Merci de votre participation.',
        inscription: nouvelleInscription
    });
});

// GET: Récupérer toutes les inscriptions (admin)
app.get('/api/inscriptions', (req, res) => {
    const data = getLesInscriptions();
    res.json(data);
});

// GET: Récupérer les statistiques
app.get('/api/statistiques', (req, res) => {
    const data = getLesInscriptions();
    res.json(data.statistiques);
});

// DELETE: Supprimer une inscription (admin)
app.delete('/api/inscriptions/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const data = getLesInscriptions();

    const index = data.inscriptions.findIndex(insc => insc.id === id);
    if (index !== -1) {
        const inscription = data.inscriptions[index];
        data.inscriptions.splice(index, 1);
        data.statistiques.total = data.inscriptions.length;
        data.statistiques.parCategorie[inscription.categorie]--;
        saveInscriptions(data);
        res.json({ success: true, message: 'Inscription supprimée' });
    } else {
        res.status(404).json({ success: false, message: 'Inscription non trouvée' });
    }
});

// GET: Page d'accueil
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// GET: Page admin
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Démarrer le serveur
app.listen(PORT, () => {
    console.log(`🚀 Serveur lancé sur http://localhost:${PORT}`);
    console.log(`📝 Site d'inscription: http://localhost:${PORT}`);
    console.log(`📊 Panel Admin: http://localhost:${PORT}/admin`);
});
