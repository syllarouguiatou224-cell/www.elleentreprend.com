# 📱 Guide Complet - Elle Entreprend UJNK 2026
## Site d'Inscription en Ligne & Gestion

---

## 🎯 Vue d'Ensemble du Projet

Vous avez maintenant un **site web complet** pour gérer les inscriptions au projet "Elle Entreprend - UJNK 2026".

**Comprend:**
- ✅ Site d'inscription responsive (mobile, tablette, PC)
- ✅ Panneau d'administration pour voir/gérer les inscriptions  
- ✅ Backend Node.js automatique avec API REST
- ✅ Stockage des données (fichier JSON ou base de données)
- ✅ Export en CSV pour vos rapports
- ✅ Design professionnel cohérent avec votre branding

---

## 📂 Fichiers du Projet

```
📦 elle_entreprend_site/
├── 📄 server.js           ← Serveur (backend)
├── 📄 package.json        ← Dépendances
├── 📁 public/
│   ├── 📄 index.html      ← Site d'inscription (frontend)
│   └── 📄 admin.html      ← Panneau d'administration
├── 📁 data/
│   └── 📄 inscriptions.json ← Données stockées automatiquement
├── 📄 README.md           ← Documentation technique
└── 📄 SETUP.sh           ← Script d'installation
```

---

## 🚀 Démarrage Rapide (Local)

### Étape 1: Vérifier Node.js
Ouvrir un terminal et taper:
```bash
node --version
```

Si vous voyez `v14.0.0` ou plus: ✅ C'est bon  
Sinon: Télécharger depuis https://nodejs.org

### Étape 2: Installer
```bash
cd elle_entreprend_site
npm install
```

### Étape 3: Lancer le serveur
```bash
npm start
```

Vous verrez:
```
🚀 Serveur lancé sur http://localhost:3000
📝 Site d'inscription: http://localhost:3000
📊 Panel Admin: http://localhost:3000/admin
```

### Étape 4: Accéder aux sites
- **Site d'inscription:** http://localhost:3000
- **Panneau admin:** http://localhost:3000/admin

---

## 🌍 Hébergement en Ligne (GRATUIT)

### Option 1️⃣: HEROKU (Recommandé - Très Facile)

**Avantages:** Simple, gratuit, support excellent

**Étapes:**

1. **Créer compte Heroku**
   - Aller à https://heroku.com
   - S'inscrire avec email/mot de passe

2. **Installer Heroku CLI**
   - Télécharger: https://devcenter.heroku.com/articles/heroku-cli
   - Installer comme un logiciel normal

3. **Se connecter**
   ```bash
   heroku login
   # Vous connecter dans le navigateur qui s'ouvre
   ```

4. **Créer une app**
   ```bash
   cd elle_entreprend_site
   heroku create elle-entreprend-ujnk-2026
   ```

5. **Déployer**
   ```bash
   git init
   git add .
   git commit -m "Elle Entreprend deployment"
   git push heroku main
   ```

6. **Ouvrir le site**
   ```bash
   heroku open
   ```

**Votre site sera à:** `https://elle-entreprend-ujnk-2026.herokuapp.com`

---

### Option 2️⃣: RENDER (Très Facile)

**Avantages:** Moderne, gratuit, interface sympa

1. **Aller sur** https://render.com
2. **Se connecter avec GitHub** (créer compte GitHub si nécessaire)
3. **Cliquer "New" → "Web Service"**
4. **Connecter le repo du projet**
5. **Configurer:**
   - Build command: `npm install`
   - Start command: `npm start`
6. **Déployer** (bouton "Deploy")

**Votre site sera automatiquement déployé** ✅

---

### Option 3️⃣: RAILWAY (Facile)

1. **Aller sur** https://railway.app
2. **Se connecter avec GitHub**
3. **Cliquer "New Project"**
4. **Sélectionner "Deploy from GitHub"**
5. **Connecter votre repo**
6. **Railway configure automatiquement** ✅

---

## 💻 Utilisation du Site

### Pour les Participantes

**URL du site:** https://votresite.com

**Elles vont:**
1. Remplir le formulaire avec leurs infos
2. Sélectionner leur catégorie (étudiante, diplômée, porteuse de projet)
3. Indiquer leurs intérêts (leadership, business, pitch, etc.)
4. Soumettre

**Ils reçoivent:**
✅ Message de confirmation
✅ Détails de l'événement (à ajouter dans le email)

---

### Pour l'Administration

**URL admin:** https://votresite.com/admin

**Vous pouvez:**
1. **Voir les stats** - Total d'inscriptions par catégorie
2. **Rechercher** - Trouver une participante par nom/email
3. **Exporter** - Télécharger en CSV pour Excel/Google Sheets
4. **Supprimer** - Retirer une inscription si nécessaire
5. **Rafraîchir** - Les données se mettent à jour automatiquement

---

## 📊 Fonctionnalités du Formulaire

Le formulaire collecte:

✅ **Infos Personnelles**
- Prénom, Nom
- Email, Téléphone

✅ **Contexte**
- Université/Institution
- Catégorie (Étudiante, Diplômée, Porteuse de Projet)
- Domaine d'intérêt (Commerce, IT, Agro, etc.)

✅ **Projet**
- Description du projet (optionnel)
- Intérêts (Leadership, Business Plan, Pitch, Networking, Finance, Mentorat)

---

## 🔐 Sécurité & Configuration

### Protéger l'Admin (Optionnel)

Modifier `server.js` pour ajouter mot de passe:

```javascript
// Après 'const app = express();'
const basicAuth = require('express-basic-auth');

app.use('/api/inscriptions', basicAuth({
  users: { 'admin': 'votreMotDePasse123' },
  challenge: true
}));
```

Ensuite:
```bash
npm install express-basic-auth
```

---

### Ajouter des Emails Automatiques

Modifier `server.js` pour envoyer confirmation automatiquement:

```javascript
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'foturemindinstitute@gmail.com',
    pass: 'votreMotDePasseGmail'  // Utiliser un mot de passe "app"
  }
});

// Ajouter dans la route POST /api/inscriptions:
await transporter.sendMail({
  from: 'foturemindinstitute@gmail.com',
  to: email,
  subject: '✅ Inscription Confirmée - Elle Entreprend UJNK 2026',
  html: `
    <h2>Bienvenue ${prenom}!</h2>
    <p>Votre inscription est confirmée pour Elle Entreprend - UJNK 2026</p>
    <p><strong>Dates:</strong> 28-29 Mars 2026</p>
    <p><strong>Lieu:</strong> Campus UJNK, Kankan</p>
    <p>À bientôt! 🚀</p>
  `
});
```

Installer:
```bash
npm install nodemailer
```

---

## 🎨 Personnaliser le Site

### Changer les Couleurs

Dans `public/index.html`, modifier la section `:root`:

```css
:root {
    --primary: #990011;           ← Couleur principale (rouge)
    --primary-light: #DB2777;     ← Rose
    --secondary: #2F3C7E;         ← Bleu
    /* ... */
}
```

### Changer le Texte

Chercher et remplacer:
- "Elle Entreprend" → Votre titre
- "UJNK 2026" → Votre période
- "foturemindinstitute@gmail.com" → Votre email
- "620770934" → Votre téléphone

### Ajouter un Logo

Dans `public/index.html`, remplacer:
```html
<div class="logo-symbol">♀</div>
```

Par:
```html
<img src="votre-logo.png" alt="Logo" style="height: 45px;">
```

---

## 📈 Analyser les Inscriptions

### Exporter les Données

1. Aller au panneau admin: https://votresite.com/admin
2. Cliquer "📥 Exporter CSV"
3. Ouvrir dans Excel/Google Sheets

### Voir les Stats

Le panneau admin montre automatiquement:
- **Total:** Nombre total d'inscriptions
- **Par catégorie:** Étudiantes, Diplômées, Porteuses de Projet
- **Date d'inscription:** Quand chaque personne s'est inscrite

---

## 🆘 Dépannage

### "Erreur: Port 3000 déjà utilisé"
```bash
# Libérer le port
lsof -i :3000
kill -9 <PID>
# Ou utiliser un autre port
PORT=3001 npm start
```

### "Erreur: npm command not found"
Node.js n'est pas installé correctement. Télécharger depuis https://nodejs.org

### "Mon site en ligne ne fonctionne pas"
- Vérifier que tous les fichiers sont uploadés
- Vérifier les logs: `heroku logs --tail`
- Vérifier que `npm start` dans package.json est correct

---

## 📞 Support & Contacts

**Pour des questions sur le projet:**

📧 Email: foturemindinstitute@gmail.com  
📱 Téléphone: +224 620 770 934  

**Pour des questions techniques:**
- Consulter le README.md du projet
- Chercher la solution sur Stack Overflow
- Me contacter pour aide

---

## ✅ Checklist Final

Avant de lancer:

- [ ] Site local testée (http://localhost:3000)
- [ ] Formulaire fonctionne (test d'inscription)
- [ ] Panneau admin accessible (voir les inscriptions)
- [ ] Site hébergé en ligne
- [ ] URL partagée avec les participantes
- [ ] Email de contact configuré
- [ ] Téléphone visible sur le site

---

## 🎉 Vous êtes Prêt!

Votre site d'inscription pour **Elle Entreprend - UJNK 2026** est maintenant **100% opérationnel**.

Partagez l'URL avec vos participantes potentielles et commencez à recevoir des inscriptions! 🚀

**Bonne chance pour l'événement!** 💪👩‍💼

---

*Site créé avec ❤️ pour l'autonomisation économique des femmes en Guinée 🇬🇳*
